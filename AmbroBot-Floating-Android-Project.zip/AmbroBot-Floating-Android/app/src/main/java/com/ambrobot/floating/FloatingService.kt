package com.ambrobot.floating

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.max

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var web: WebView? = null
    private val bg = Color.rgb(12, 14, 23)
    private val card = Color.rgb(26, 29, 44)
    private val accent = Color.rgb(157, 139, 255)
    private val prefs by lazy { getSharedPreferences("ambrobot", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotification()
        if (Settings.canDrawOverlays(this)) showBubble()
    }

    private fun createNotification() {
        val channel = "ambrobot_overlay"
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel, "AmbroBot floating assistant", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, FloatingService::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
        startForeground(42, notification.setContentTitle("AmbroBot is ready").setContentText("Tap the floating bubble to open your assistant.").setSmallIcon(android.R.drawable.ic_dialog_info).addAction(Notification.Action.Builder(null, "Stop bubble", stop).build()).build())
    }

    private fun params(w: Int, h: Int, gravity: Int = Gravity.TOP or Gravity.START): WindowManager.LayoutParams = WindowManager.LayoutParams(w, h, if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { this.gravity = gravity }

    private fun showBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return
        val b = TextView(this).apply {
            text = "✦"; textSize = 27f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(0xFF5E4BC4.toInt()); setStroke(2, 0xFFB4A6FF.toInt()) }
            elevation = 12f
        }
        val p = params(dp(58), dp(58)).apply { x = dp(12); y = dp(190) }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var dragged = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; dragged=false; return true }
                    MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt(); if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) dragged=true; p.x=max(0, ox+dx); p.y=max(0, oy+dy); try { wm.updateViewLayout(b,p) } catch (_: Exception) {}; return true }
                    MotionEvent.ACTION_UP -> { if (!dragged) showPanel(); return true }
                }; return false
            }
        })
        bubble = b
        try { wm.addView(b, p) } catch (_: Exception) { bubble = null }
    }

    private fun showPanel() {
        if (panel != null) { closePanel(); return }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); background = android.graphics.drawable.GradientDrawable().apply { setColor(bg); cornerRadius = dp(22).toFloat(); setStroke(dp(1), 0xFF5145A5.toInt()) }; clipToOutline = true; elevation = 18f }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(8), dp(10)); setBackgroundColor(card) }
        bar.addView(TextView(this).apply { text = "✦  AmbroBot AI"; textSize = 17f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
        fun actionButton(label: String, action: () -> Unit) = TextView(this).apply { text = label; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(10), dp(5), dp(10), dp(5)); setOnClickListener { action() } }
        bar.addView(actionButton("—") { closePanel() })
        bar.addView(actionButton("×") { closePanel() })
        root.addView(bar)
        val address = prefs.getString("site_url", "") ?: ""
        if (address.startsWith("https://")) {
            val w = WebView(this).apply {
                setBackgroundColor(bg); settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.loadsImagesAutomatically = true
                webViewClient = WebViewClient(); webChromeClient = WebChromeClient()
                loadUrl(address)
            }
            web = w
            root.addView(w, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            val empty = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(22), dp(24), dp(22), dp(24)) }
            empty.addView(TextView(this).apply { text = "Your assistant is ready."; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
            empty.addView(TextView(this).apply { text = "Add your live AmbroBot HTTPS website in the app to use AI chat here. The floating menu already works without it."; textSize = 14f; setTextColor(0xFFB9BED0.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(20)) })
            empty.addView(TextView(this).apply { text = "OPEN APP SETTINGS"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(16), dp(12), dp(16), dp(12)); background = android.graphics.drawable.GradientDrawable().apply { cornerRadius=dp(12).toFloat(); setColor(0xFF5145A5.toInt()) }; setOnClickListener { closePanel(); val i=Intent(this@FloatingService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) } })
            root.addView(empty, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(7), dp(12), dp(7)); setBackgroundColor(card) }
        footer.addView(TextView(this).apply { text = "DRAG THE ✦ BUBBLE TO MOVE IT"; textSize = 10f; setTextColor(0xFF9299B0.toInt()) }, LinearLayout.LayoutParams(0, -2, 1f))
        footer.addView(TextView(this).apply { text = "Hide bubble"; textSize = 12f; setTextColor(0xFFD6D0FF.toInt()); setPadding(dp(8), dp(7), dp(8), dp(7)); setOnClickListener { closePanel(); removeBubble() } })
        root.addView(footer)
        val p = params((resources.displayMetrics.widthPixels - dp(28)).coerceAtMost(dp(480)), (resources.displayMetrics.heightPixels * 0.72f).toInt(), Gravity.CENTER).apply { flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL; x=0; y=0 }
        panel = root
        try { wm.addView(root, p) } catch (_: Exception) { panel = null }
    }

    private fun closePanel() { try { web?.stopLoading(); web?.destroy(); web=null; panel?.let { wm.removeView(it) } } catch (_: Exception) {}; panel=null }
    private fun removeBubble() { closePanel(); try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}; bubble=null; stopSelf() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { removeBubble(); return START_NOT_STICKY }
        if (bubble == null && Settings.canDrawOverlays(this)) showBubble()
        return START_STICKY
    }
    override fun onDestroy() { closePanel(); try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}; bubble=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
