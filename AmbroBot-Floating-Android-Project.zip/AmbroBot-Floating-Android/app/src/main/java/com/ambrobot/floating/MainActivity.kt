package com.ambrobot.floating

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ambrobot", MODE_PRIVATE) }
    private val bg = Color.rgb(12, 14, 23)
    private val card = Color.rgb(26, 29, 44)
    private val accent = Color.rgb(157, 139, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24); setBackgroundColor(bg) }
        root.addView(TextView(this).apply { text = "✦  AmbroBot AI"; textSize = 29f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply { text = "FLOATING ASSISTANT"; textSize = 12f; setTextColor(accent); setPadding(0, 8, 0, 24) })
        root.addView(TextView(this).apply { text = "Your AI, one tap away."; textSize = 19f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply { text = "Set your live AmbroBot HTTPS address, then enable the bubble. You can hide it or turn it off whenever you want."; textSize = 14f; setTextColor(0xFFB9BED0.toInt()); setPadding(0, 10, 0, 20) })
        root.addView(TextView(this).apply { text = "AMBROBOT WEBSITE URL"; textSize = 12f; setTextColor(0xFFB9BED0.toInt()); setPadding(0, 4, 0, 8) })
        val url = EditText(this).apply { setSingleLine(true); hint = "https://your-ambrobot-site.example"; setHintTextColor(0xFF777D92.toInt()); setTextColor(Color.WHITE); textSize = 14f; setPadding(14, 12, 14, 12); setBackgroundColor(card); setText(prefs.getString("site_url", "") ?: "") }
        root.addView(url, LinearLayout.LayoutParams(-1, 54))
        val note = TextView(this).apply { text = "No website address yet? You can still test the floating menu, but AI chat needs the hosted AmbroBot server."; textSize = 12f; setTextColor(0xFF9299B0.toInt()); setPadding(0, 12, 0, 20) }
        root.addView(note)
        fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(0xFF5145A5.toInt()); setOnClickListener { action() } }
        root.addView(button("Save website address") { val value = url.text.toString().trim().trimEnd('/'); if (value.isNotEmpty() && !value.startsWith("https://")) { Toast.makeText(this, "Please use a secure https:// address", Toast.LENGTH_LONG).show() } else { prefs.edit().putString("site_url", value).apply(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() } }, LinearLayout.LayoutParams(-1, 52))
        val gap = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, 8) }; root.addView(gap)
        root.addView(button("Enable floating bubble") {
            val value = url.text.toString().trim().trimEnd('/')
            if (value.isNotEmpty() && !value.startsWith("https://")) { Toast.makeText(this, "Use an https:// address", Toast.LENGTH_LONG).show(); return@button }
            prefs.edit().putString("site_url", value).apply()
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else { startService(Intent(this, FloatingService::class.java)); Toast.makeText(this, "AmbroBot bubble enabled", Toast.LENGTH_SHORT).show() }
        }, LinearLayout.LayoutParams(-1, 52))
        root.addView(button("Hide / stop floating bubble") { stopService(Intent(this, FloatingService::class.java)); Toast.makeText(this, "Floating bubble stopped", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1, 52))
        root.addView(TextView(this).apply { text = "Privacy tip: only enter a website URL you trust. Never paste your AI API key into this app."; textSize = 12f; setTextColor(0xFF777D92.toInt()); setPadding(0, 20, 0, 0) })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); if (Settings.canDrawOverlays(this) && intent.getBooleanExtra("start_overlay", false)) startService(Intent(this, FloatingService::class.java)) }
}
