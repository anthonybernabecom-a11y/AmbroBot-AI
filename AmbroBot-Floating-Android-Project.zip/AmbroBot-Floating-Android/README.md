# AmbroBot AI — Floating Android App (starter project)

This is the Android Studio source project for a removable floating AmbroBot bubble and popup. It is a native Android overlay, not a website shortcut.

## Features in this starter
- Draggable floating ✦ bubble
- Tap to open a compact popup
- Close/minimize popup controls
- “Hide bubble” control and notification action to stop it
- Settings screen to enter the hosted AmbroBot HTTPS URL
- Popup loads the configured AmbroBot website so the existing account/chat UI can run inside it

## Important limitation
The latest AmbroBot ZIP contains a Node.js backend. It does not include a live hosted URL, and opening the files from `content://` cannot run that backend. Until you deploy the AmbroBot server and enter its HTTPS URL in this app, the popup will show a setup message instead of live AI chat. Do not put AI API keys directly in the Android app.

## Build
Open this folder in Android Studio on a computer with Android SDK installed, sync Gradle, then Build > Build APK(s). This workspace does not contain a compiled APK. Android requires the user to grant “Display over other apps” permission before enabling the bubble.

## Android permissions
The app requests overlay permission only when you tap Enable floating bubble. The service runs as a foreground service while the bubble is active; use Hide / stop floating bubble or the notification action to stop it.

## Build from an Android phone using GitHub Actions
1. Create a GitHub repository and upload the contents of this project folder (not the ZIP file itself).
2. Open the repository's **Actions** tab and run **Build AmbroBot APK** (or push to the `main` branch).
3. When the workflow finishes, open the run and download the `ambrobot-floating-debug-apk` artifact. Extract it and install `app-debug.apk`, allowing installs from your browser/files app if Android asks.

The workflow builds a debug APK for testing, not a Play Store release. This project has not been compiled or device-tested in this workspace.
